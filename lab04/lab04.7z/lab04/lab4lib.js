var button = document.createElement("button");

function monthsUA(date) {
    var months = ['січня', 'лютого', 'березня', 'квітня', 'травня',
        'червня', 'липня', 'серпня', 'вересня', 'жовтня',
        'листопада', 'грудня'];
    return months[date.getMonth()];
}

function daysUA(date) {
    var days = [ 'неділя', 'понеділок', 'вівторок', 'середа', 'четвер', "п'ятниця", 'субота'];
    return days[date.getDay()];
}

function timeCreator(date) {
    var hours = date.getHours();
    var minutes = date.getMinutes();
    var seconds = date.getSeconds();

    if (hours < 10)
        hours = '0' + hours;
    if (minutes < 10)
        minutes = '0' + minutes;
    if (seconds < 10)
        seconds = '0' + seconds;
    return hours + ':' + minutes + ':' + seconds;
}

function task1(date){
    var result = '',
        strDate = 'Дата: ' + date.getDate() + ' ' + monthsUA(date) + ' ' + date.getFullYear() + ' року',
        strDay = 'День: ' + daysUA(date),
        strTime = 'Час: ' + timeCreator(date);

    result = strDate + '<br/>' + strDay + '<br/>' + strTime;
    return result;
}

function task2(date){
    obj = {};
    if(date.getDay() === 0)
        obj.dayNumber = 7;
    else
        obj.dayNumber = date.getDay();
    obj.dayName = daysUA(date);
    return obj;
}

function task3(daysAgo, date){
    var dateCopy = new Date(date);
    if (+daysAgo < 0) {
        dateCopy.setDate(dateCopy.getDate() + +daysAgo);
        daysAgo = -daysAgo;
    }
    else
        dateCopy.setDate(dateCopy.getDate() - +daysAgo);
    return daysAgo + ' дні(днів) назад було ' + dateCopy.getDate() + ' число';
}

function task4(year, month) {
    var date = new Date(year, month, 0);
    return date.getDate()+ ' останній день ' + monthsUA(date) + ' ' + date.getFullYear() + ' року';
}

function task5(date){
    var obj = {};
    obj.secondsPassed = date.getHours() * 3600 + date.getMinutes() * 60 + date.getSeconds();

    var tomorrow = new Date(date.getFullYear(), date.getMonth(), date.getDate()+1);
    obj.secondsLeft = Math.round((tomorrow - date)/1000);

    return obj;
}

function task6(date) {

    var dat = date.getDate();
    if (dat < 10)
        dat = '0' + dat;

    var month = date.getMonth() + 1;
    if (month < 10)
        month = '0' + month;

    var year = date.getFullYear();

    return 'дата у форматі: ' + dat + '.' + month + '.' + year;
}

function task7(firstDate, secondDate){
    var first = Date.parse(firstDate);
    var second = Date.parse(secondDate);
    var difference =  Math.floor(first - second);
    var oneDayInMS = 1000 * 60 * 60 * 24;

    var days = Math.abs(Math.floor(difference/oneDayInMS));

    return 'Різниця: ' + days + ' днів ';
}

function formatDate(date) {
    var difference = new Date() - date;

    if (difference < 1000) {
        return 'тільки що';
    }

    var sec = Math.floor(difference / 1000);

    if (sec < 60) {
        return sec + ' сек. назад';
    }

    var min = Math.floor(difference / 60000);
    if (min < 60) {
        return min + ' хв. назад';
    }

    var d = date;
    d = [
        '0' + d.getDate(),
        '0' + (d.getMonth() + 1),
        '' + d.getFullYear(),
        '0' + d.getHours(),
        '0' + d.getMinutes()
    ];

    for (var i = 0; i < d.length; i++) {
        d[i] = d[i].slice(-2);
    }

    return d.slice(0, 3).join('.') + ' ' + d.slice(3).join(':');
}

function task9(date, input){
    var newDate;
    newDate = new Date(Date.parse(input));
    return newDate;
}

function task10(language, date){
    var options = {
        era: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        weekday: 'long',
        timezone: 'UTC',
        hour: 'numeric',
        minute: 'numeric',
        second: 'numeric'
    };
    return date.toLocaleString(language, options);
}
