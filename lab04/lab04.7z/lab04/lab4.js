function Task1(){
    var date = new Date();
    var elem = document.getElementById('task1');
    elem.innerHTML = task1(date);
}

function Task2(){
    var date = new Date();
    var elem = document.getElementById('task2');
    var obj = task2(date);
    elem.innerHTML = 'Номер дня: ' + obj.dayNumber + '<br/>' + 'Назва дня: ' + obj.dayName;
}

function isNumeric(n) {
    return !isNaN(parseInt(n)) && isFinite(n);
}

function Task3(){
    var date = new Date();
    var elem = document.getElementById('task3');
    var daysAgo = document.getElementById('daysAgo').value;
    if (isNumeric(daysAgo))
        elem.innerHTML = task3(daysAgo, date);
}

function Task4(){
    var elem = document.getElementById('task4');
    var year = +document.getElementById('year').value;
    var month = +document.getElementById('month').value;
    if(isNumeric(month) && isNumeric(year) && year > 0 && month > 0 && month <= 12)
        elem.innerHTML = task4(year, month);
}


function Task5(){
    var elem = document.getElementById('task5');
    var date = new Date();
    var obj = task5(date);
    elem.innerHTML = obj.secondsPassed + ' секунд пройшло <br/>' + obj.secondsLeft + ' секунд залишилось';
}

function Task6(){
    var elem = document.getElementById('task6');
    var date = new Date();
    elem.innerHTML = task6(date);
}

function Task7(){
    var elem = document.getElementById('task7');
    var firstDate = document.getElementById('firstDate').value;
    var secondDate = document.getElementById('secondDate').value;

    if (isNaN(firstDate) && isNaN(secondDate))
        elem.innerHTML = task7(firstDate, secondDate);
}

var dateOnLoad = new Date();

function Task8(){
    var elem = document.getElementById('task8');
    elem.innerHTML = formatDate(dateOnLoad);
}

function Task9() {
    var elem = document.getElementById('task9');
    var date = new Date();
    var input = document.getElementById('textDate').value;
    elem.innerHTML = task9(date, input)
}

function Task10() {
    var elem = document.getElementById('task10');
    var date = new Date();
    var lang = document.getElementById('language').value;
    elem.innerHTML = task10(lang, date);
}
